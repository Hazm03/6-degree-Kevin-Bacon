# Kevin-Bacon


![kevinBacon](https://github.com/MatthewBoden/Kevin-Bacon/assets/50034384/51b763f4-3200-40bb-9625-36074f2e324e)


1. Al Pacino has a bacon number of 1. This is because he acted in "A Few Good Men" with
Kevin Bacon.
2. Keanu Reeves has a bacon number of 2. This is because he acted in "The Devil's
Advocate" with Al Pacino, who acted in a "A Few Good Men" with Kevin Bacon
3. Hugo Weaving has a bacon number of 3. This is because he acted in "The Matrix" trilogy
series with Keanu Reeves. Keanu Reeves acted with Al Pacino in "The Devil's Advocate",
and Al Pacino acted with Kevin Bacon in "A Few Good Men”
4. You guessed it, KevinBacon himself has bacon number 0.
